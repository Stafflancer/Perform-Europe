<?php

namespace AC;

interface Sanitize {

	public function sanitize( array $data ): array;

}