<?php

namespace AC\Helper\Select;

interface Label {

	public function get_label( $entity ): string;

}