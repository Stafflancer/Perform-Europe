/*
* datatable JQuery plugin: used for better table display
* version: 1.10.18
* https://datatables.net/
*/

jQuery(document).ready(function () {
	jQuery(".um_addon_user_list_table").DataTable();
});