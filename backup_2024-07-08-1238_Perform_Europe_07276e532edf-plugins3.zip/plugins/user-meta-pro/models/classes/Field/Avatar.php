<?php
namespace UserMeta\Field;

/**
 * Handle user_avatar field.
 *
 * @author Khaled Hossain
 * @since 1.4.0
 */
class Avatar extends File
{
}