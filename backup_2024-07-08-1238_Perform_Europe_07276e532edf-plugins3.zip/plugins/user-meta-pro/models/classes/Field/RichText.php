<?php
namespace UserMeta\Field;

/**
 * Handle rich_text field.
 *
 * @author Khaled Hossain
 * @since 1.4.0
 */
class RichText extends Description
{
}