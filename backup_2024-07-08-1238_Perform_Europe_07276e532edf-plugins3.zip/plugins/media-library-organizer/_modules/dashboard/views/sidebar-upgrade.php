<?php
/**
 * Outputs settings screen sidebar for free plugins with a pro version.
 * Display the reasons to upgrade and the mailing list.
 *
 * @package WPZincDashboardWidget
 * @author WP Zinc
 */

/**
 * Settings screen sidebar for free plugins with a pro version. Display the reasons to upgrade
 * and the mailing list.
 */

