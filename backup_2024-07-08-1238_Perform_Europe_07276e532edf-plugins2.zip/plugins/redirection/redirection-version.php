<?php

define( 'REDIRECTION_VERSION', '5.4.2' );
define( 'REDIRECTION_BUILD', '2dfac6cbb88915145528d6945ba453dd' );
define( 'REDIRECTION_MIN_WP', '5.7' );
